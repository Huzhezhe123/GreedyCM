import numpy as np

N = 100

class Graph:
	def _init_(self,name,list,neighbors,connecters,max_node_num):
		self.name = name
		self.list = []
		self.neighbors = np.zeros((N,N))
		self.max_node_num = max_node_num
		#self.connecters = np.array((N,N),dtype = str)
		# self.connecters = np.array([np.arange(N), np.arange(N)],dtype = str)

	def printGraphname(self):
		print(self.name)

	def printGraphList(self):
		for i in range(len(self.list)):
			print(self.list[i].num)
			print(self.list[i].connecter)
	def printEdges(self):
		print("-----------------",self.name,"---------------------")
		for i in range(len(self.list)):
			# print("node",self.list[i].num,"has connecter",self.list[i].connecter)
			for j in range(len(self.list)):
				#print(self.list[i].num,self.list[j].num)
				if self.neighbors[self.list[i].num][self.list[j].num] == 1:
					print("node",self.list[i].num,"is conneted to ",self.list[j].num,", the connecter is ",self.connecters[self.list[i].num][self.list[j].num])
		print("---------------------------------------------------")
	def printNode(self):
		for i in range(0,self.Get_node_num()):
			print(self.name,"has node",self.list[i].num)


	def CreatNewNode(self,num,connecter_num):
		node = Graph_node()
		node.num = num
		node.connecter = [0,0,0,0]
		node.neighbors = []
		node.connecter_set(connecter_num)
		#print(self.name," succesfully create node",num)
		self.list.append(node)

	def add(self,node_a,node_b,connecter_a,connecter_b):	
		a = -1
		b = -1
		for i in range(len(self.list)):
			if self.list[i].num == node_a:
				a = i
			if self.list[i].num == node_b:
				b = i
		if (self.list[a].connecter[connecter_a] == 1) and (self.list[b].connecter[connecter_b] == 1):
			self.neighbors[node_a][node_b] = 1 #建立一个边
			self.neighbors[node_b][node_a] = 1 #反向建立一个边
			self.connecters[node_a][node_b] = num2abcd(connecter_a)+num2abcd(connecter_b)
			self.connecters[node_b][node_a] = num2abcd(connecter_b)+num2abcd(connecter_a)
			print(self.name," succesfully add node",node_a,"to",node_b," with connecter ",num2abcd(connecter_a)+num2abcd(connecter_b))
		else:
			print("add_wrong!")

	def add2(self,node_a,node_b,connecter_a,connecter_b):
		a = -1
		b = -1
		for i in range(len(self.list)):
			if self.list[i].num == node_a:
				a = i
			if self.list[i].num == node_b:
				b = i
		self.neighbors[node_a][node_b] = 1  # 建立一个边
		self.neighbors[node_b][node_a] = 1  # 反向建立一个边
		self.connecters[node_a][node_b] = connecter_a
		self.connecters[node_b][node_a] = connecter_b



	def clear_edge(self,node_a,node_b):
		for i in range(len(self.list)):
			if self.list[i].num == node_a or self.list[i].num == node_b:
				self.list[i].num = -1

		self.neighbors[node_a][node_b] = 0
		self.neighbors[node_b][node_a] = 0
		self.connecters[node_a][node_b] = "101"
		self.connecters[node_b][node_a] = "101"


	def Get_node_num(self):
		num = 0
		for i in range(0,len(self.list)):
			if self.list[i].num > 0:
				num = num + 1
		return num

	def printGraph(self):
		print(self.name,"has ",len(self.list)," nodes")
		



class Graph_node:
	def _init_(self,num,connecter):
		self.num = num
		self.connecter = []
	# 设置connecter最多有4个，如果=0说明没有连接器可以使用，=1说明该连接器被使用
	def connecter_set(self,connecter_num):
		for i in range(len(connecter_num)):
			self.connecter[connecter_num[i]] = 1


def num2abcd(num):
	num = num + 1
	if num == 1:
		return "a"
	elif num == 2:
		return "b"
	elif num == 3:
		return "c"
	else:
		return "d"





