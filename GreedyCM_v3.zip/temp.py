import pickle
import numpy
import matplotlib.pyplot as plt
import numpy as np

filename = 'times'
f = open(filename, 'rb')
times = pickle.load(f)
f.close()


st = 10
ed = 200
x = []
y = []
for node_num in range(st,ed):
	print(node_num,"个节点耗时：",times[node_num])
	x.append(node_num)
	y.append(times[node_num])



print(x)
plt.plot(x,y)
plt.show()

