import numpy as np
from graph_node_v3 import *
from randGraph_v3 import *

# 初始化函数
def Init():
	# 初始化，创建两张图
	X = Graph()
	X.name = "Initial_Graph"
	X.list = []
	X.neighbors = np.zeros((N,N))
	X.connecters = [None]*N
	for i in range(N):
		X.connecters[i] = ["one"]*N

	G = Graph()
	G.name = "Goal_Graph"
	G.list = []
	G.neighbors = np.zeros((N,N))
	G.connecters = [None]*N
	for i in range(N):
		G.connecters[i] = ["one"]*N

	# 起点终点图添加14个节点
	for i in range(1,16):
		X.CreatNewNode(i,[0,1,2,3])
		G.CreatNewNode(i,[0,1,2,3])

	
	# 添加边，4个数字，前两个代表两个节点，后面两个代表分别的连接器
	X.add(1,2,2,0)
	X.add(2,3,3,0)
	X.add(3,4,1,0)
	X.add(4,5,2,1)
	X.add(5,6,2,0)
	X.add(6,7,3,0)
	X.add(6,13,2,3)
	X.add(13,14,1,3)
	X.add(7,8,1,0)
	X.add(8,9,2,1)
	X.add(9,10,2,1)
	X.add(10,11,3,0)
	X.add(11,12,1,0)
	X.add(12,15,1,0)

	G.add(1,2,1,0)
	G.add(2,3,2,1)
	G.add(3,4,2,1)
	G.add(4,5,3,0)
	G.add(5,6,1,0)
	G.add(6,7,2,1)
	G.add(6,13,3,3)
	G.add(13,14,1,3)
	G.add(7,8,2,0)
	G.add(8,9,3,0)
	G.add(9,10,1,0)
	G.add(10,11,2,1)
	G.add(11,12,2,0)
	G.add(2,15,1,0)


	# 打印
	#X.printEdges()
	#X.printGraph()
	#X.printGraph()

	#G.printEdges()
	#G.printGraph()
	#G.printGraph()
	return X,G


def MCESC_UV(X,G,i,j,matching_set):
	# 初始化
	node_num = X.Get_node_num()
	matching_set[i][j] = 1  #记为被标记

	# 1、获得X的第i个节点的邻居节点集合，Y的第j个节点的邻居节点集合
	# 获取节点index
	index_X = -1
	index_G = -1
	for a in range(node_num):
		if i == X.list[a].num:
			index_X = i
		if j == G.list[a].num:
			index_G = j
	# 获取邻居节点，存入一个集合
	neighbors_list_X = []
	neighbors_list_G = []
	for a in range(1,node_num+1):
		if X.neighbors[index_X][a] == 1: # 有连接
			neighbors_list_X.append(a)
		if G.neighbors[index_G][a] == 1:
			neighbors_list_G.append(a)
	#print("i = ",i,", neighbors_list_X = ",neighbors_list_X)
	#print("j = ",j,", neighbors_list_G = ",neighbors_list_G)

	# 2、开始遍历
	for a in range(len(neighbors_list_X)):
		# 获取边
		edge_X = X.connecters[index_X][neighbors_list_X[a]]
		for b in range(len(neighbors_list_G)):
			edge_G = G.connecters[index_G][neighbors_list_G[b]]
			# print(edge_X)
			# print(edge_G)
			if (edge_G != edge_X) or matching_set[neighbors_list_X[a]][neighbors_list_G[b]] == 1:
				continue
			else:
				MCESC_UV(X,G,neighbors_list_X[a],neighbors_list_G[b],matching_set)	


	return matching_set


def print_matching_set(matching_set):
	len_matching_set = len(matching_set)
	for i in range(len_matching_set):
		for j in range(len_matching_set):
			if matching_set[i][j] == 1:
				print("(X",i,",G",j,"),")

def get_matching_num(matching_set):
	len_matching_set = len(matching_set)
	matching_num = 0
	for i in range(len_matching_set):
		for j in range(len_matching_set):
			if matching_set[i][j] == 1:
				matching_num = matching_num + 1
	return matching_num


def get_index(index,all_matching_set):
	len_matching_set = len(all_matching_set)
	max_index = 0
	max_num = 0
	X_index = []
	G_index = []

	for i in range(len_matching_set):
		if get_matching_num(all_matching_set[i]) > max_num:
			max_num = get_matching_num(all_matching_set[i])
			max_index = i
	matching_set = all_matching_set[max_index]
	for i in range(len(matching_set)):
		for j in range(len(matching_set)):
			if (matching_set[i][j] == 1):
				X_index.append(i)
				G_index.append(j)
	return X_index,G_index


def upadte(temp, matching_num, X_index, G_index):
	for i in range(1,len(matching_num)):
		matching_num[i] = 0
		for j in range(1,len(matching_num)):
			if i in X_index:
				for k in range(0,len(matching_num)):
					temp[i][j][k] = 0
			else:
				temp[i][j][X_index] = 0

			for m in range(1,len(matching_num)):
				for n in range(len(G_index)):
					g = G_index[n]
					temp[i][j][m][g] = 0

			matching_num[i] = max(matching_num[i],get_matching_num(temp[i][j]))
	for i in range(1,len(matching_num)):
		if i in X_index:
			matching_num[i] = 0
	return matching_num



X,G = Init()
X_node_num = X.Get_node_num()
G_node_num = G.Get_node_num()
matching_set = np.zeros((X_node_num+2,G_node_num+2))


temp = [None]*(X_node_num+1)
# temp_G = [None]*(G_node_num+1)
for i in range(X_node_num+1):
	temp[i] = [matching_set]*(X_node_num+1)
	# temp_G[i] = 

# temp = [matching_set]*(X_node_num+1)

matching_num = np.zeros(X_node_num+1)


for i in range(1,X_node_num+1):
	for j in range(1,G_node_num+1):
		matching_set = np.zeros((X_node_num + 1,G_node_num + 1))
		matching_set = MCESC_UV(X,G,i,j,matching_set)
		if matching_num[i] <= get_matching_num(matching_set):
			matching_num[i] = get_matching_num(matching_set)
		temp[i][j] = matching_set




# G_index = [1,2,3]
# print(temp[1][7])
# print(get_matching_num(temp[1][7]))


MCESC = []


print("result：----------------------")
n = 1
while np.sum(matching_num) != 0:
	#print("matching_num before: ",matching_num)
	#print(np.sum(matching_num))
	index = np.argmax(matching_num)
	max_num = matching_num[index]
	X_index,G_index = get_index(index,temp[index])
	print("-------------------第",n,"组匹配点-------------------")
	n = n + 1
	for i in range(len(X_index)):
		print("起始图的节点",X_index[i],"和终点图的节点",G_index[i],"匹配")
	# print(X_index)
	# print(G_index)

	# 根据X_index和G_index更新matching_num
	matching_num = upadte(temp, matching_num, X_index,G_index)
	#print("matching_num after: ",matching_num)
	#matching_num = 0








