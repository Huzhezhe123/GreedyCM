import networkx as nx
import matplotlib.pyplot as plt
from graph_node_v3 import *

def main():
    G = nx.Graph()
    # 添加对应的边和点
    for i in range(1,15):
        G.add_node(i, desc='X'+str(i))  # desc为标签即结点名称
    G.add_edge(1, 2)          # 添加边
    G.add_edge(2, 3)
    G.add_edge(3, 4)
    G.add_edge(4, 5)
    G.add_edge(5, 6)
    G.add_edge(6, 7)
    G.add_edge(6, 13)
    G.add_edge(13, 14)
    G.add_edge(7, 8)
    G.add_edge(8, 9)
    G.add_edge(9, 10)
    G.add_edge(10,11)
    G.add_edge(11,12)

    pos = [(1,3),(1, 3), (2, 4), (2, 2),  (2, 1),  (3, 3),  (4, 1),  (5, 4),  (5, 2),  (6, 3), (5, 3), (6, 4), (3,4), (4,4),(1,2)]  # pos列表从第0位开始，但我定义是从结点1开始，这里令前两个坐标相同
    # 按pos所定位置画出节点,无标签
    nx.draw_networkx(G, pos, with_labels=None)
    # 画出标签
    node_labels = nx.get_node_attributes(G, 'desc')
    nx.draw_networkx_labels(G, pos, labels=node_labels)

    plt.title('test', fontsize=10)
    plt.show()


if __name__ == '__main__':
    main()
