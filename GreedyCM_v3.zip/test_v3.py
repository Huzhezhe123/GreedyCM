import numpy as np
from graph_node_v3 import *
from randGraph_v3 import *
from visul import *
import datetime

# 初始化函数
def Init(node_num):
	# 初始化，创建两张图
	X = Graph()
	X.name = "Initial_Graph"
	X.list = []
	X.neighbors = np.zeros((N,N))
	X.connecters = [None]*N
	for i in range(N):
		X.connecters[i] = ["one"]*N

	G = Graph()
	G.name = "Goal_Graph"
	G.list = []
	G.neighbors = np.zeros((N,N))
	G.connecters = [None]*N
	for i in range(N):
		G.connecters[i] = ["one"]*N


	
	# 起点终点图添加14个节点
	for i in range(1,node_num+1):
		X.CreatNewNode(i,[0,1,2,3])
		G.CreatNewNode(i,[0,1,2,3])

	# rand_genGraph_and_edge(G,node_num)

	# 添加边，4个数字，前两个代表两个节点，后面两个代表分别的连接器
	G = rand_genGraph_and_edge(G,node_num)
	X = rand_genGraph_and_edge(X,node_num)
	# visualizer(X)
	# visualizer(G)
	# plt.show()
	# # 打印
	# X.printEdges()
	# X.printGraph()
	# X.printGraph()

	# G.printEdges()
	# G.printGraph()
	# G.printGraph()
	return X,G


def MCESC_UV(X,G,i,j,matching_set):
	# 初始化
	node_num = X.Get_node_num()
	matching_set[i][j] = 1  #记为被标记

	# 1、获得X的第i个节点的邻居节点集合，Y的第j个节点的邻居节点集合
	# 获取节点index
	index_X = -1
	index_G = -1
	for a in range(node_num):
		if i == X.list[a].num:
			index_X = i
		if j == G.list[a].num:
			index_G = j
	# 获取邻居节点，存入一个集合
	neighbors_list_X = []
	neighbors_list_G = []
	for a in range(1,node_num+1):
		if X.neighbors[index_X][a] == 1: # 有连接
			neighbors_list_X.append(a)
		if G.neighbors[index_G][a] == 1:
			neighbors_list_G.append(a)
	#print("i = ",i,", neighbors_list_X = ",neighbors_list_X)
	#print("j = ",j,", neighbors_list_G = ",neighbors_list_G)

	# 2、开始遍历
	for a in range(len(neighbors_list_X)):
		# 获取边
		edge_X = X.connecters[index_X][neighbors_list_X[a]]
		for b in range(len(neighbors_list_G)):
			edge_G = G.connecters[index_G][neighbors_list_G[b]]
			# print(edge_X)
			# print(edge_G)
			if (edge_G != edge_X) or matching_set[neighbors_list_X[a]][neighbors_list_G[b]] == 1:
				continue
			else:
				MCESC_UV(X,G,neighbors_list_X[a],neighbors_list_G[b],matching_set)	


	return matching_set


def print_matching_set(matching_set):
	len_matching_set = len(matching_set)
	for i in range(len_matching_set):
		for j in range(len_matching_set):
			if matching_set[i][j] == 1:
				print("(X",i,",G",j,"),")

def get_matching_num(matching_set):
	len_matching_set = len(matching_set)
	matching_num = 0
	for i in range(len_matching_set):
		for j in range(len_matching_set):
			if matching_set[i][j] == 1:
				matching_num = matching_num + 1
	return matching_num


def get_index(index,all_matching_set):
	len_matching_set = len(all_matching_set)
	max_index = 0
	max_num = 0
	X_index = []
	G_index = []

	for i in range(len_matching_set):
		if get_matching_num(all_matching_set[i]) > max_num:
			max_num = get_matching_num(all_matching_set[i])
			max_index = i
	matching_set = all_matching_set[max_index]
	for i in range(len(matching_set)):
		for j in range(len(matching_set)):
			if (matching_set[i][j] == 1):
				X_index.append(i)
				G_index.append(j)
	return X_index,G_index


def upadte(temp, matching_num, X_index, G_index):
	for i in range(1,len(matching_num)):
		matching_num[i] = 0
		for j in range(1,len(matching_num)):
			if i in X_index:
				for k in range(0,len(matching_num)):
					temp[i][j][k] = 0
			else:
				temp[i][j][X_index] = 0

			for m in range(1,len(matching_num)):
				for n in range(len(G_index)):
					g = G_index[n]
					temp[i][j][m][g] = 0

			matching_num[i] = max(matching_num[i],get_matching_num(temp[i][j]))
	for i in range(1,len(matching_num)):
		if i in X_index:
			matching_num[i] = 0
	return matching_num

def MCESC_algorithm(node_num):
	starttime = datetime.datetime.now()
	X,G = Init(node_num)
	endtime = datetime.datetime.now()
	time1 = (endtime - starttime).seconds
	print("随机生成两张包含",node_num,"个节点的图，花费时间",time1,'秒')


	temp_X = X
	temp_G = G
	X_node_num = X.Get_node_num()
	G_node_num = G.Get_node_num()
	matching_set = np.zeros((X_node_num+2,G_node_num+2))


	temp = [None]*(X_node_num+1)
	# temp_G = [None]*(G_node_num+1)
	for i in range(X_node_num+1):
		temp[i] = [matching_set]*(X_node_num+1)
		# temp_G[i] = 

	# temp = [matching_set]*(X_node_num+1)

	matching_num = np.zeros(X_node_num+1)


	starttime = datetime.datetime.now()

	for i in range(1,X_node_num+1):
		for j in range(1,G_node_num+1):
			matching_set = np.zeros((X_node_num + 1,G_node_num + 1))
			matching_set = MCESC_UV(X,G,i,j,matching_set)
			if matching_num[i] <= get_matching_num(matching_set):
				matching_num[i] = get_matching_num(matching_set)
			temp[i][j] = matching_set

	endtime = datetime.datetime.now()
	time2 = (endtime - starttime).seconds
	print("算法运行耗时：",time2,'秒')


	# G_index = [1,2,3]
	# print(temp[1][7])
	# print(get_matching_num(temp[1][7]))


	starttime = datetime.datetime.now()
	# 使用一个三元数组存储MCESC
	MCESC = np.zeros((X_node_num+1,X_node_num+1,X_node_num+1))

	print("result：----------------------")
	n = 1
	while np.sum(matching_num) != 0:
		#print("matching_num before: ",matching_num)
		#print(np.sum(matching_num))
		index = np.argmax(matching_num)
		max_num = matching_num[index]
		X_index,G_index = get_index(index,temp[index])
		print("-------------------第",n,"组匹配点-------------------")
		n = n + 1
		for i in range(len(X_index)):
			print("起始图的节点",X_index[i],"和终点图的节点",G_index[i],"匹配")
			MCESC[n][X_index[i]][G_index[i]] = 1
		# print(X_index)
		# print(G_index)

		# 根据X_index和G_index更新matching_num
		matching_num = upadte(temp, matching_num, X_index,G_index)
		#print("matching_num after: ",matching_num)
		#matching_num = 0

	endtime = datetime.datetime.now()
	time3 = (endtime - starttime).seconds
	print("回溯运行耗时：",time3,'秒')


	# 一共n组匹配点
	# print(n)
	# print(MCESC)

	# visualizer2_subplot(temp_X)
	# visualizer2_subplot(temp_G)
	visualizer3(temp_X,temp_G,n-1,MCESC)

	plt.show()
	return time1,time2,time3



node_num = 20
time1,time2,time3 = MCESC_algorithm(node_num)
# time = np.zeros((node_num,3))
# for i in range(30,node_num):
# 	time1,time2,time3 = MCESC_algorithm(i)
# 	time[i][0] = time1
# 	time[i][1] = time2
# 	time[i][2] = time3
	
# for i in range(71,node_num):
# 	print(i,"个节点的图，花费时间",time[i][1],"，回溯算法耗时：",time[i][2])

# 30 个节点的图，花费时间 0.0 ，回溯算法耗时： 2.0
# 31 个节点的图，花费时间 0.0 ，回溯算法耗时： 2.0
# 32 个节点的图，花费时间 0.0 ，回溯算法耗时： 3.0
# 33 个节点的图，花费时间 0.0 ，回溯算法耗时： 3.0
# 34 个节点的图，花费时间 0.0 ，回溯算法耗时： 3.0
# 35 个节点的图，花费时间 0.0 ，回溯算法耗时： 4.0
# 36 个节点的图，花费时间 0.0 ，回溯算法耗时： 5.0
# 37 个节点的图，花费时间 0.0 ，回溯算法耗时： 5.0
# 38 个节点的图，花费时间 0.0 ，回溯算法耗时： 6.0
# 39 个节点的图，花费时间 0.0 ，回溯算法耗时： 6.0
# 40 个节点的图，花费时间 0.0 ，回溯算法耗时： 10.0
# 41 个节点的图，花费时间 0.0 ，回溯算法耗时： 9.0
# 42 个节点的图，花费时间 1.0 ，回溯算法耗时： 12.0
# 43 个节点的图，花费时间 1.0 ，回溯算法耗时： 8.0
# 44 个节点的图，花费时间 1.0 ，回溯算法耗时： 14.0
# 45 个节点的图，花费时间 1.0 ，回溯算法耗时： 13.0
# 46 个节点的图，花费时间 1.0 ，回溯算法耗时： 16.0
# 47 个节点的图，花费时间 1.0 ，回溯算法耗时： 17.0
# 48 个节点的图，花费时间 1.0 ，回溯算法耗时： 17.0
# 49 个节点的图，花费时间 1.0 ，回溯算法耗时： 23.0
# 50 个节点的图，花费时间 2.0 ，回溯算法耗时： 24.0
# 51 个节点的图，花费时间 2.0 ，回溯算法耗时： 22.0
# 52 个节点的图，花费时间 2.0 ，回溯算法耗时： 26.0
# 53 个节点的图，花费时间 2.0 ，回溯算法耗时： 36.0
# 54 个节点的图，花费时间 2.0 ，回溯算法耗时： 32.0
# 55 个节点的图，花费时间 2.0 ，回溯算法耗时： 37.0
# 56 个节点的图，花费时间 3.0 ，回溯算法耗时： 37.0
# 57 个节点的图，花费时间 3.0 ，回溯算法耗时： 48.0
# 58 个节点的图，花费时间 3.0 ，回溯算法耗时： 46.0
# 59 个节点的图，花费时间 3.0 ，回溯算法耗时： 46.0
# 60 个节点的图，花费时间 4.0 ，回溯算法耗时： 59.0
# 61 个节点的图，花费时间 4.0 ，回溯算法耗时： 56.0
# 62 个节点的图，花费时间 4.0 ，回溯算法耗时： 63.0
# 63 个节点的图，花费时间 4.0 ，回溯算法耗时： 80.0
# 64 个节点的图，花费时间 5.0 ，回溯算法耗时： 81.0
# 65 个节点的图，花费时间 5.0 ，回溯算法耗时： 76.0
# 66 个节点的图，花费时间 5.0 ，回溯算法耗时： 91.0
# 67 个节点的图，花费时间 6.0 ，回溯算法耗时： 92.0
# 68 个节点的图，花费时间 6.0 ，回溯算法耗时： 80.0
# 69 个节点的图，花费时间 6.0 ，回溯算法耗时： 97.0
