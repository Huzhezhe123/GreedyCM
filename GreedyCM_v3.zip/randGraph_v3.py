import random
import numpy as np
from visul import *

def check(G):
	for i in range(1,len(G)):
		if sum(G[i]) == 0:
			return 0
	return 1

def num2abcd(num):
	num = num + 1
	if num == 1:
		return "a"
	elif num == 2:
		return "b"
	elif num == 3:
		return "c"
	else:
		return "d"

def gen_rand_graph(node_num):
	# 100个节点
	# node_num = 50
	edge_num = node_num-1
	curr_edge_num = 0

	# 邻接矩阵表示图
	G = [None]*(node_num+1)
	for i in range(node_num+1):
		G[i] = [0]*(node_num+1)

	#print(G)

	# 记录每个节点的连接器 0 1 2 3，-1代表没有连接，0123代表abcd
	connecters = [-1]*(node_num+1)
	edge_connecters = [None]*(node_num+1) # 记录两个节点连接
	for i in range(node_num+1):
		edge_connecters[i] = ["0"]*(node_num+1)


	# 先给图里赛一个节点1
	node_list = []
	node_list.append(1)
	# print(len(node_list))
	# print(random.randint(1,len(node_list)))
	# print(sum(G[1]))



	while(curr_edge_num < edge_num):
		# 如果每个节点都连过其他点，就完成建图
		flag = check(G)
		# print(G)
		# print(node_list)
		if flag == 1:
			break


		# 让a作为图内已经有的节点，b作为生长出来的节点
		a = random.randint(1,len(node_list))
		a = node_list[a-1]

		b = random.randint(1,node_num)
		while b in node_list:
			b = random.randint(1,node_num)
		if a == b:
			continue

		#如果有边，就continue掉
		if G[a][b] == 1 or G[b][a] == 1:
			continue

		#如果一个节点上面练连了4个及以上的边，continue掉
		temp1 = 0
		temp2 = 0
		for i in range(node_num+1):
			if G[i][b] == 1:
				temp1 = temp1 + 1
			if G[a][i] == 1:
				temp2 = temp2 + 1
		if temp1 >= 4 or temp2 >= 4:
			continue

		# 如果加了这个边后形成了环，就continue掉


		# 记录连接器以及边
		connecters[a] = connecters[a] + 1
		connecters[b] = connecters[b] + 1
		edge_connecters[a][b] = num2abcd(connecters[a]) + num2abcd(connecters[b])
		edge_connecters[b][a] = num2abcd(connecters[b]) + num2abcd(connecters[a])
		# print(a,b,edge_connecters[a][b])

		G[a][b] = 1
		G[b][a] = 1
		node_list.append(b)
		curr_edge_num = curr_edge_num + 1


	return G,edge_connecters


def rand_genGraph_and_edge(G,node_num):
	RandGraph,edge_connecters = gen_rand_graph(node_num)
	for i in range(1,len(RandGraph)):
		for j in range(1,len(RandGraph)):
			if RandGraph[i][j] == 1:
				a,b = handle_edge_connecters(edge_connecters,i,j)
				G.add(i,j,a,b)
	return G

def handle_edge_connecters(edge_connecters,i,j):
	temp = edge_connecters[i][j]
	a = temp[0]
	b = temp[1]
	if a == 'a':
		a = 0
	elif a == 'b':
		a = 1
	elif a == 'c':
		a = 2
	else:
		a = 3
	if b == 'a':
		b = 0
	elif b == 'b':
		b = 1
	elif b == 'c':
		b = 2
	else:
		b = 3
	return a,b


# node_num = 30
# RandGraph,edge_connecters = gen_rand_graph(node_num)
# print("--------------------------------")
# for i in range(1,len(RandGraph)):
# 		for j in range(1,len(RandGraph)):
# 			if RandGraph[i][j] == 1:
# 				a,b = handle_edge_connecters(edge_connecters,i,j)
# 				print(i,j,a,b)

# print(RandGraph)

# print(G)
# t = 0
# for i in range(node_num+1):
# 	temp = 0
# 	for j in range(node_num + 1):
# 		if G[i][j] == 1:
# 			print("node:",i,"连接node:",j)
# 			temp = temp + 1
# 	if temp == 0:
# 		t = t + 1









# print(G)
# print(t)

# print("G.add_edge")


















