class Graph:
	def _init_(self,name,list):
		self.name = name
		self.list = []

	def printGraphname(self):
		print(self.name)

	def printGraphList(self):
		for i in range(len(self.list)):
			print(self.list[i].num)

	def CreatNewNode(self,num):
		node = Graph_node()
		node.num = num
		self.list.append(node)

	def add(a,b,weight):
		


class Graph_node:
	def _init_(self,num):
		self.num = num



g = Graph()
g.name = "aaa"
g.list = []
g.printGraphname()
g.CreatNewNode(1)
g.CreatNewNode(2)
g.printGraphList()




