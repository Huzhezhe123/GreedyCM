import numpy as np
from graph_node_v3 import *

# 初始化，创建两张图
X = Graph()
X.name = "Initial_Graph"
X.list = []
X.neighbors = np.zeros((N,N))
X.connecters = [None]*N
for i in range(N):
	X.connecters[i] = ["one"]*N

G = Graph()
G.name = "Goal_Graph"
G.list = []
G.neighbors = np.zeros((N,N))
G.connecters = [None]*N
for i in range(N):
	G.connecters[i] = ["one"]*N

# 起点图添加14个节点
X.CreatNewNode(1,[0,1,2,3])
X.CreatNewNode(2,[0,1,2,3])
X.CreatNewNode(3,[0,1,2,3])
X.CreatNewNode(4,[0,1,2,3])
X.CreatNewNode(5,[0,1,2,3])
X.CreatNewNode(6,[0,1,2,3])
X.CreatNewNode(7,[0,1,2,3])
X.CreatNewNode(8,[0,1,2,3])
X.CreatNewNode(9,[0,1,2,3])
X.CreatNewNode(10,[0,1,2,3])
X.CreatNewNode(11,[0,1,2,3])
X.CreatNewNode(12,[0,1,2,3])
X.CreatNewNode(13,[0,1,2,3])
X.CreatNewNode(14,[0,1,2,3])

# 终点图添加14个节点
G.CreatNewNode(1,[0,1,2,3])
G.CreatNewNode(2,[0,1,2,3])
G.CreatNewNode(3,[0,1,2,3])
G.CreatNewNode(4,[0,1,2,3])
G.CreatNewNode(5,[0,1,2,3])
G.CreatNewNode(6,[0,1,2,3])
G.CreatNewNode(7,[0,1,2,3])
G.CreatNewNode(8,[0,1,2,3])
G.CreatNewNode(9,[0,1,2,3])
G.CreatNewNode(10,[0,1,2,3])
G.CreatNewNode(11,[0,1,2,3])
G.CreatNewNode(12,[0,1,2,3])
G.CreatNewNode(13,[0,1,2,3])
G.CreatNewNode(14,[0,1,2,3])

# 添加边，4个数字，前两个代表两个节点，后面两个代表分别的连接器
X.add(1,2,2,0)
X.add(2,3,3,0)
X.add(3,4,1,0)
X.add(4,5,2,1)
X.add(5,6,2,0)
X.add(6,7,3,0)
X.add(6,13,2,3)
X.add(13,14,1,3)
X.add(7,8,1,0)
X.add(8,9,2,1)
X.add(9,10,2,1)
X.add(10,11,3,0)
X.add(11,12,1,0)

G.add(1,2,1,0)
G.add(2,3,2,1)
G.add(3,4,2,1)
G.add(4,5,3,0)
G.add(5,6,1,0)
G.add(6,7,2,1)
G.add(6,13,3,3)
G.add(13,14,1,3)
G.add(7,8,2,0)
G.add(8,9,3,0)
G.add(9,10,1,0)
G.add(10,11,2,1)
G.add(11,12,2,0)


X.printEdges()
X.printGraph()
X.printGraph()

G.printEdges()
G.printGraph()
G.printGraph()

