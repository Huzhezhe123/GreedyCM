import turtle
from queue import Queue
from test_v1 import *

turtle.color("red") #将画笔变更为红色
turtle.pensize(3)


def draw_cube(x,y,node_num):
	turtle.penup()
	turtle.goto(x,y)#将画笔放置到坐标为（100,0）的位置上
	turtle.write(node_num,move = False,align = "right",font = ("Times New Roman",14,"normal"))

	x = x - 25
	y = y - 25
	#turtle.dot(20)
	turtle.goto(x,y)#将画笔放置到坐标为（100,0）的位置上
	
	#turtle.dot(20)
	
	turtle.pendown()
	for i in range(4):
		turtle.forward(50)
		turtle.left(90)

# def draw_graph(G):

def draw_node(t,i):



X,G = Init()
# 开一个二维数组记录当前节点四周有没有被占
# 1234代表右上左下，temp[1][2]代表1号节点的上面被占
node_num = G.Get_node_num()
temp = [None]*(node_num+1)
for i in range(node_num+1):
	temp[i] = [0]*(node_num+1)

# BFS遍历
q = Queue(node_num+1)

q.put(G.list[0].num)
pre_node = 0

while(not(q.empty())):
	t = q.get()
	for i in range(1,5):
		if temp[pre_node][i] == 0:
			draw_node(t,i)
	print(t)


# turtle.dot(20)
# draw_cube(100,100,"1")
# draw_cube(200,200,"2")

# turtle.hideturtle()#隐藏绘画箭头
# turtle.done()




