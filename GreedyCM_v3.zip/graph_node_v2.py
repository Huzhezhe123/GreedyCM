class Graph:
	def _init_(self,name,list):
		self.name = name
		self.list = []

	def printGraphname(self):
		print(self.name)

	def printGraphList(self):
		for i in range(len(self.list)):
			print(self.list[i].num)
			print(self.list[i].connecter)

	def CreatNewNode(self,num,connecter_num):
		node = Graph_node()
		node.num = num
		node.connecter = ['0','0','0','0']
		node.neighbors = [][]
		node.connecter_set(connecter_num)
		self.list.append(node)

	def add(self,node_a,node_b,weight):
		node_a.neighbors[0][0] = 




class Graph_node:
	def _init_(self,num,connecter,neighbors):
		self.num = num
		self.connecter = []
		self.neighbors = [][]
	# 设置connecter最多有4个，如果=0说明没有被占，=abcd说明被占
	def connecter_set(self,connecter_num):
		for i in range(4):
			if self.connecter[i] == '0':
				self.connecter[i] = connecter_num
				break



# 初始化
g = Graph()
g.name = "aaa"
g.list = []
g.printGraphname()
g.CreatNewNode(1,'a')
g.CreatNewNode(2,'a')
g.printGraphList()




