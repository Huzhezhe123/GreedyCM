from graph_node_v3 import *
import networkx as nx
import matplotlib.pyplot as plt
def visualizer(G):
    plt.figure()
    G1 = nx.Graph()
    # 添加对应的边和点
    node_num=G.Get_node_num()
    for i in range(1,node_num+1):
        G1.add_node(i, desc='X'+str(i))  # desc为标签即结点名称
    # for a in range(0,len(G.neighbors_list_G)):
    #     edges=(G.connecters[index_G][neighbors_list_G[a]])          # 添加边
    for i in range(0,len(G.list)):
        for j in range(1,len(G.neighbors)):
            if G.neighbors[G.list[i].num][j] == 1:
                G1.add_edge(G.list[i].num,j)
    #G.add_edge(2, 3)
    #G.add_edge(3, 4)
    #G.add_edge(4, 5)
    #G.add_edge(5, 6)
    #G.add_edge(6, 7)
    #G.add_edge(6, 13)
    #G.add_edge(13, 14)
    #G.add_edge(7, 8)
    #G.add_edge(8, 9)
    #G.add_edge(9, 10)
    #G.add_edge(10,11)
    #G.add_edge(11,12)
    # G1.add_edges_from(edges)
    pos =nx.spring_layout(G1) #[(1,3),(1, 3), (2, 4), (2, 2),  (2, 1),  (3, 3),  (4, 1),  (5, 4),  (5, 2),  (6, 3), (5, 3), (6, 4), (3,4), (4,4),(1,2)]  # pos列表从第0位开始，但我定义是从结点1开始，这里令前两个坐标相同
    # 按pos所定位置画出节点,无标签
    nx.draw_networkx_nodes(G1, pos)
    nx.draw_networkx_edges(G1,pos)
    # 画出标签
    node_labels = nx.get_node_attributes(G1, 'desc')
    nx.draw_networkx_labels(G1, pos, labels=node_labels)
    #left,bottom,width,height=(1,2,3,3)
    #rect=patches.Rectangle((left,bottom),width,height,fill=False,color="purple",linewidth=2)
    #plt.gca().add_patch(rect)
    plt.title(G.name, fontsize=10)
    plt.show()

def visualizer2_subplot(G):
    if G.name == "Initial_Graph":
        plt.subplot(1,2,1)
    else:
        plt.subplot(1,2,2)
    # plt.figure()
    G1 = nx.Graph()
    # 添加对应的边和点
    node_num=G.Get_node_num()
    for i in range(1,node_num+1):
        G1.add_node(i, desc='X'+str(i))  # desc为标签即结点名称
    # for a in range(0,len(G.neighbors_list_G)):
    #     edges=(G.connecters[index_G][neighbors_list_G[a]])          # 添加边
    for i in range(0,len(G.list)):
        for j in range(1,len(G.neighbors)):
            if G.neighbors[G.list[i].num][j] == 1:
                G1.add_edge(G.list[i].num,j)

    pos =nx.spring_layout(G1) 
    nx.draw_networkx_nodes(G1, pos,nodelist = [1,2],node_color = randomcolor())
    nx.draw_networkx_edges(G1,pos,style = '--',edge_color = 'blue')
    # 画出标签
    node_labels = nx.get_node_attributes(G1, 'desc')
    nx.draw_networkx_labels(G1, pos, labels=node_labels)
    #left,bottom,width,height=(1,2,3,3)
    #rect=patches.Rectangle((left,bottom),width,height,fill=False,color="purple",linewidth=2)
    #plt.gca().add_patch(rect)
    plt.title(G.name, fontsize=10)
    print(G1[2])
    # plt.show()


def visualizer3(X,G,n,MCESC):
    if G.name == "Initial_Graph":
        plt.subplot(1,2,1)
    else:
        plt.subplot(1,2,2)
    # plt.figure()

    X1 = nx.Graph()
    # 添加对应的边和点
    node_num=X.Get_node_num()
    for i in range(1,node_num+1):
        X1.add_node(i, desc='X'+str(i))  # desc为标签即结点名称

    for i in range(0,len(X.list)):
        for j in range(1,len(X.neighbors)):
            if X.neighbors[X.list[i].num][j] == 1:
                X1.add_edge(X.list[i].num,j,name=X.connecters[X.list[i].num][j])


    G1 = nx.Graph()
    # 添加对应的边和点
    node_num=G.Get_node_num()
    for i in range(1,node_num+1):
        G1.add_node(i, desc='G'+str(i))  # desc为标签即结点名称
    # for a in range(0,len(G.neighbors_list_G)):
    #     edges=(G.connecters[index_G][neighbors_list_G[a]])          # 添加边
    for i in range(0,len(G.list)):
        for j in range(1,len(G.neighbors)):
            if G.neighbors[G.list[i].num][j] == 1:
                G1.add_edge(G.list[i].num,j,name=G.connecters[X.list[i].num][j])



    pos_X = nx.spring_layout(X1)
    pos_G = nx.spring_layout(G1)

    # 存储颜色
    randomcolor_set = []
    for i in range(0,n+1):
        randomcolor_set.append(randomcolor())


    matching_index_X = []
    matching_index_G = []
    # 分别处理两个子图
    for i in range(0,n+1):
        # 获取第i个MCESC
        matching_set = MCESC[i+1]
        temp_index_X = []
        temp_index_G = []
        for j in range(1,node_num+1):
            for k in range(1,node_num+1):
                if matching_set[j][k] == 1:
                    temp_index_X.append(j)
                    temp_index_G.append(k) 
        matching_index_X.append(temp_index_X)
        matching_index_G.append(temp_index_G)

    # 开始画图
    # 先画起始图
    plt.subplot(1,2,1)
    for i in range(0,len(matching_index_X)):
        nx.draw_networkx_nodes(X1, pos_X,nodelist = matching_index_X[i],node_color = randomcolor_set[i],node_shape='s',alpha=1, linewidths=8)
    edge_labels = nx.get_edge_attributes(X1, 'name')
    nx.draw_networkx_edges(X1,pos_X,style = '--',edge_color = 'blue', width=2,alpha=0.5) # 画边
    node_labels = nx.get_node_attributes(X1, 'desc')
    nx.draw_networkx_labels(X1, pos_X, labels=node_labels,font_size=15)
    nx.draw_networkx_edge_labels(X1, pos_X, edge_labels=edge_labels)
    plt.title(X.name, fontsize=10)

    plt.subplot(1,2,2)
    for i in range(0,len(matching_index_G)):
        nx.draw_networkx_nodes(G1, pos_G,nodelist = matching_index_G[i],node_color = randomcolor_set[i],node_shape='s',alpha=1, linewidths=8) # 画节点
    
    nx.draw_networkx_edges(G1,pos_G,style = '--',edge_color = 'blue', width=2,alpha=0.5) # 画边
    node_labels = nx.get_node_attributes(G1, 'desc')
    nx.draw_networkx_labels(G1, pos_G, labels=node_labels,font_size=15)# 画节点上的文字
    edge_labels = nx.get_edge_attributes(G1, 'name')
    nx.draw_networkx_edge_labels(G1, pos_G, edge_labels=edge_labels)
    plt.title(G.name, fontsize=10)

    # plt.show()


import random
def randomcolor():
    colorArr = ['1','2','3','4','5','6','7','8','9','A','B','C','D','E','F']
    color = ""
    for i in range(6):
        color += colorArr[random.randint(0,14)]
    return "#"+color

